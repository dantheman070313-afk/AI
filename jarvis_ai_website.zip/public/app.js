const state = {
  history: [],
  memory: JSON.parse(localStorage.getItem("jarvis_memory") || "[]"),
  listening: false,
  mission: null,
  map: null,
  mapMarker: null,
  recognition: null
};

const el = (id) => document.getElementById(id);

function addActivity(text) {
  const node = document.createElement("div");
  node.textContent = "▸ " + text;
  el("activity").prepend(node);
  while (el("activity").children.length > 8) el("activity").lastChild.remove();
}

function setCore(mode, status) {
  el("core").className = "core " + (mode || "");
  el("coreState").textContent = status;
  el("assistantStatus").textContent = status;
}

function toast(message) {
  const t = el("toast");
  t.textContent = message;
  t.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.remove("show"), 2600);
}

function addMessage(role, text, cards = []) {
  const node = document.createElement("div");
  node.className = `message ${role}`;
  node.innerHTML = `
    <div class="message-head">
      <span>${role === "user" ? "YOU" : "JARVIS"}</span>
      <span>${new Date().toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"})}</span>
    </div>
    <div>${escapeHtml(text).replace(/\n/g, "<br>")}</div>
  `;
  if (cards?.length) {
    const grid = document.createElement("div");
    grid.style.cssText = "display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:7px;margin-top:10px;";
    cards.forEach(c => {
      const card = document.createElement("div");
      card.style.cssText = "padding:8px;border:1px solid rgba(0,200,255,.13);background:rgba(0,200,255,.04);border-radius:8px;";
      card.innerHTML = `<div style="font-size:9px;color:#718797;letter-spacing:.12em;">${escapeHtml(c.label || "")}</div><div style="margin-top:4px;font-size:11px;color:#cfefff;">${escapeHtml(c.value || "")}</div>`;
      grid.appendChild(card);
    });
    node.appendChild(grid);
  }
  el("messages").appendChild(node);
  el("messages").scrollTop = el("messages").scrollHeight;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  })[c]);
}

function renderMemory() {
  el("memoryCount").textContent = state.memory.length;
  const wrap = el("memoryList");
  wrap.innerHTML = "";
  if (!state.memory.length) {
    wrap.innerHTML = '<div class="muted">No long-term memory stored.</div>';
    return;
  }
  state.memory.slice(-6).reverse().forEach(item => {
    const div = document.createElement("div");
    div.className = "memory-item";
    div.textContent = item;
    wrap.appendChild(div);
  });
}

function remember(item) {
  state.memory.push(item);
  state.memory = state.memory.slice(-20);
  localStorage.setItem("jarvis_memory", JSON.stringify(state.memory));
  renderMemory();
}

function updateClock() {
  el("clock").textContent = new Date().toLocaleTimeString();
}
setInterval(updateClock, 1000);
updateClock();

function updateStats() {
  el("cpu").textContent = `${18 + Math.floor(Math.random() * 28)}%`;
  el("mem").textContent = `${35 + Math.floor(Math.random() * 18)}%`;
}
setInterval(updateStats, 2400);
updateStats();

state.map = L.map("map", { zoomControl: false }).setView([40.7128, -74.0060], 3);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "&copy; OpenStreetMap contributors"
}).addTo(state.map);

function moveMap(city, lat, lng) {
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || (!lat && !lng)) {
    toast("No map coordinates returned.");
    return;
  }
  state.map.setView([lat, lng], 12, { animate: true });
  if (state.mapMarker) state.map.removeLayer(state.mapMarker);
  state.mapMarker = L.marker([lat, lng]).addTo(state.map);
  state.mapMarker.bindPopup(`<b>${escapeHtml(city || "Location")}</b>`).openPopup();
  el("mapCaption").textContent = `Locked on ${city || "requested location"}.`;
}

async function askJarvis(text) {
  const message = text.trim();
  if (!message) return;

  addMessage("user", message);
  state.history.push({ role: "user", text: message });
  el("commandInput").value = "";

  setCore("processing", "PROCESSING");
  el("greeting").textContent = "Analyzing your request…";
  addActivity("Processing user command");

  try {
    const response = await fetch("/api/jarvis", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message,
        history: state.history,
        memory: state.memory
      })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Request failed");

    addMessage("jarvis", data.reply, data.data_cards);
    state.history.push({ role: "assistant", text: data.reply });

    const action = data.action || "none";
    addActivity(`Action: ${action.toUpperCase()}`);

    if (action === "map") {
      moveMap(data.map_city, data.map_lat, data.map_lng);
    }

    if (/remember that|remember this|remember:/i.test(message)) {
      remember(message.replace(/.*?remember(?: that| this|:)?/i, "").trim());
    }

    if (action === "focus") {
      document.body.classList.toggle("focus-mode");
      toast("Focus mode toggled.");
    }

    if (action === "tasks" || /mission/i.test(message)) {
      const clean = message.replace(/start (a )?mission( to)?/i, "").trim();
      if (clean) {
        state.mission = { name: clean, pct: 15 };
        updateMission();
      }
    }

    el("greeting").textContent = data.reply.slice(0, 120);
    setCore("", "SYSTEM ONLINE");
  } catch (err) {
    addActivity("Request failed");
    addMessage("jarvis", `I couldn't complete that request. ${err.message}`);
    toast("JARVIS request failed.");
    setCore("", "ERROR");
    setTimeout(() => setCore("", "SYSTEM ONLINE"), 1200);
  }
}

function updateMission() {
  if (!state.mission) return;
  el("missionName").textContent = state.mission.name;
  el("missionDetail").textContent = "Mission active • command center tracking progress";
  el("missionPct").textContent = `${state.mission.pct}%`;
  el("missionRing").style.background = `radial-gradient(circle at center, #07121a 54%, transparent 55%), conic-gradient(var(--cyan) ${state.mission.pct * 3.6}deg, rgba(0,200,255,.09) 0deg)`;
}

el("sendBtn").addEventListener("click", () => askJarvis(el("commandInput").value));
el("commandInput").addEventListener("keydown", (e) => {
  if (e.key === "Enter") askJarvis(el("commandInput").value);
});

document.querySelectorAll("[data-command]").forEach(btn => {
  btn.addEventListener("click", () => askJarvis(btn.dataset.command));
});

el("clearBtn").addEventListener("click", () => {
  state.history = [];
  el("messages").innerHTML = "";
  addMessage("jarvis", "Conversation cleared. Systems remain online.");
});

document.querySelectorAll("[data-tool]").forEach(btn => {
  btn.addEventListener("click", () => {
    const tool = btn.dataset.tool;
    addActivity(`Tool selected: ${tool.toUpperCase()}`);
    if (tool === "voice") startVoice();
    else if (tool === "vision") el("imageInput").click();
    else if (tool === "maps") {
      moveMap("New York City", 40.7128, -74.0060);
      toast("Map console focused.");
    } else if (tool === "memory") {
      toast(`${state.memory.length} memory items loaded.`);
    } else {
      toast(`${tool.toUpperCase()} console ready.`);
    }
  });
});

el("visionBtn").addEventListener("click", () => el("imageInput").click());

el("imageInput").addEventListener("change", async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;

  setCore("processing", "VISION");
  addActivity("Image received");
  addMessage("user", `Analyze image: ${file.name}`);

  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const response = await fetch("/api/jarvis/vision", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image_url: reader.result })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Vision failed");

      const summary = `${data.summary}\nScene: ${data.scene}\nPalette: ${data.palette}\nConfidence: ${data.confidence}%`;
      addMessage("jarvis", summary, [
        { label: "OBJECTS", value: (data.objects || []).join(", ") || "None detected" }
      ]);
      addActivity("Vision analysis complete");
    } catch (err) {
      addMessage("jarvis", `Vision analysis failed. ${err.message}`);
    } finally {
      setCore("", "SYSTEM ONLINE");
      e.target.value = "";
    }
  };
  reader.readAsDataURL(file);
});

function startVoice() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    toast("Voice recognition is not supported in this browser.");
    return;
  }

  if (state.listening && state.recognition) {
    state.recognition.stop();
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.lang = "en-US";
  recognition.interimResults = false;
  recognition.continuous = false;

  state.recognition = recognition;
  state.listening = true;
  el("waveform").classList.add("active");
  setCore("listening", "LISTENING");
  el("greeting").textContent = "Listening…";
  addActivity("Voice control activated");

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    el("commandInput").value = transcript;
  };

  recognition.onend = () => {
    state.listening = false;
    el("waveform").classList.remove("active");
    setCore("", "SYSTEM ONLINE");
    const text = el("commandInput").value.trim();
    if (text) askJarvis(text);
  };

  recognition.onerror = () => {
    state.listening = false;
    el("waveform").classList.remove("active");
    setCore("", "SYSTEM ONLINE");
    toast("Voice input failed.");
  };

  recognition.start();
}

el("micBtn").addEventListener("click", startVoice);

renderMemory();
updateMission();
