import express from "express";
import cors from "cors";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(cors());
app.use(express.json({ limit: "15mb" }));

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

const SYSTEM = `
You are JARVIS, a highly advanced personal AI operating system.
Personality:
- Calm
- Precise
- Professional
- Extremely intelligent
- Occasionally dryly witty
- Respectful toward the user
- Keep spoken replies concise unless more detail is required

Choose one action:
- "search" for current web information
- "map" when the user wants a place shown/located
- "tasks" for tasks/missions
- "focus" for focus mode
- "vision" for image analysis
- "calc" for mathematics
- "none" otherwise

For map requests, return map_city, map_lat, map_lng when possible.
Optionally return up to 4 data_cards with label/value.
`;

function needsWebSearch(message: string) {
  return /weather|news|price|stock|today|latest|search|who is|what is happening|score/i.test(message);
}

function safeHistory(value: unknown) {
  if (!Array.isArray(value)) return [];
  return value.slice(-8).map((m: any) => ({
    role: m?.role === "user" ? "user" : "assistant",
    text: String(m?.text || "").slice(0, 600)
  }));
}

function safeMemory(value: unknown) {
  return Array.isArray(value) ? value.slice(0, 10) : [];
}

app.get("/api/health", (_req, res) => {
  res.json({ name: "JARVIS", status: "online", timestamp: new Date().toISOString() });
});

app.post("/api/jarvis", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim().slice(0, 2000);
    if (!message) return res.status(400).json({ error: "message required" });

    const history = safeHistory(req.body?.history);
    const memory = safeMemory(req.body?.memory);
    const web = needsWebSearch(message);

    const transcript = history
      .map((m: any) => `${m.role === "user" ? "USER" : "JARVIS"}: ${m.text}`)
      .join("\n");

    const prompt = `${SYSTEM}

Known memory:
${JSON.stringify(memory).slice(0, 1200)}

Conversation:
${transcript || "(none)"}

USER:
${message}

Return JSON:
{
  "reply": "string",
  "action": "search|map|tasks|focus|vision|calc|none",
  "map_city": "string",
  "map_lat": number,
  "map_lng": number,
  "data_cards": [{"label":"string","value":"string"}]
}`;

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6",
      input: prompt,
      ...(web ? { tools: [{ type: "web_search" as const }] } : {}),
      text: {
        format: {
          type: "json_schema",
          name: "jarvis_response",
          strict: true,
          schema: {
            type: "object",
            additionalProperties: false,
            properties: {
              reply: { type: "string" },
              action: {
                type: "string",
                enum: ["search", "map", "tasks", "focus", "vision", "calc", "none"]
              },
              map_city: { type: "string" },
              map_lat: { type: "number" },
              map_lng: { type: "number" },
              data_cards: {
                type: "array",
                maxItems: 4,
                items: {
                  type: "object",
                  additionalProperties: false,
                  properties: {
                    label: { type: "string" },
                    value: { type: "string" }
                  },
                  required: ["label", "value"]
                }
              }
            },
            required: ["reply", "action", "map_city", "map_lat", "map_lng", "data_cards"]
          }
        }
      }
    });

    let result: any;
    try {
      result = JSON.parse(response.output_text);
    } catch {
      result = {
        reply: response.output_text,
        action: "none",
        map_city: "",
        map_lat: 0,
        map_lng: 0,
        data_cards: []
      };
    }

    res.json(result);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "JARVIS encountered an internal error." });
  }
});

app.post("/api/jarvis/vision", async (req, res) => {
  try {
    const imageUrl = String(req.body?.image_url || "").trim();
    if (!imageUrl) return res.status(400).json({ error: "image_url required" });

    const response = await openai.responses.create({
      model: process.env.OPENAI_VISION_MODEL || "gpt-5.6",
      input: [{
        role: "user",
        content: [
          {
            type: "input_text",
            text: `Analyze this image like JARVIS. Return JSON with:
summary (one sentence),
objects (max 8),
scene,
palette,
confidence (0-100).`
          },
          {
            type: "input_image",
            image_url: imageUrl,
            detail: "auto"
          }
        ]
      }],
      text: {
        format: {
          type: "json_schema",
          name: "vision_result",
          strict: true,
          schema: {
            type: "object",
            additionalProperties: false,
            properties: {
              summary: { type: "string" },
              objects: { type: "array", maxItems: 8, items: { type: "string" } },
              scene: { type: "string" },
              palette: { type: "string" },
              confidence: { type: "number" }
            },
            required: ["summary", "objects", "scene", "palette", "confidence"]
          }
        }
      }
    });

    res.json(JSON.parse(response.output_text));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Vision analysis failed." });
  }
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`JARVIS online at http://localhost:${PORT}`);
});
