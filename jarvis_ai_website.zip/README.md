# JARVIS AI Website

A standalone futuristic JARVIS-style AI command center with:

- Text chat
- Voice control through browser speech recognition
- Vision/image analysis
- Web search through the OpenAI Responses API
- Interactive world map
- Memory stored locally in the browser
- Mission mode
- System radar
- AI activity feed
- Futuristic responsive UI

## 1. Requirements

- Node.js 20+
- An OpenAI API key

## 2. Install

```bash
npm install
```

## 3. Configure

Copy `.env.example` to `.env` and add your API key:

```env
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-5.6
OPENAI_VISION_MODEL=gpt-5.6
PORT=3000
```

Never put your OpenAI API key in `public/app.js`.

## 4. Run

```bash
npm run dev
```

Then open:

http://localhost:3000

## 5. Production build

```bash
npm run build
npm start
```

## Notes

The map uses OpenStreetMap tiles through Leaflet.
Voice recognition depends on browser support for the Web Speech API.
